<template>
  <div class="hello">
      <h1>{{msg}}</h1>
      <el-form :inline="true" :model="form" ref="form" :rules="formrules">
          <el-form-item label="用户名:" prop="user">
              <el-input v-model="form.user" type="text"></el-input>
          </el-form-item>
          <br>
          <el-form-item label="密 码 :" prop="pass">
              <el-input v-model="form.pass" type="password" style="margin-left: 8px"></el-input>
          </el-form-item>
      </el-form>
      <div>
          <el-button @click="login('form')" icon="el-icon-user" type="success">登录</el-button>
      </div> 
  </div>
</template>

<script>
export default {
    data(){
        return {
            msg: '欢迎登陆博客管理系统',
            form:{
                user: '',
                pass: '',
                sage:''
            },
            formrules:{
                user:[{required:true,message:'请输入用户名',trigger:'blur'}],
                pass:[{required:true,message:'请输入密码',trigger:'blur'}],
            }
        }
    },
    methods:{
        login(form){
            this.$refs[form].validate((valid)=>{
                if(valid){
                    let params = {
                        username: this.form.user,
                        password: this.form.pass
                    }
                    this.$axios.post("http://127.0.0.1:8888/admin/login",params).then(res=>{
                        if(res.data != 1){
                            localStorage.setItem('name',res.data[0].a_name)
                            this.$router.push({
                                path: '/index'
                            })
                            this.$message({
                                type:'success',
                                message:'登录成功'
                            })
                        } else {
                            this.$message({
                                type:'danger',
                                message:'登录失败'
                            })
                        }   
                    })
                }  
            })
            this.form.user = ''
            this.form.pass = ''
        },
    }
}
</script>

<style>
    .hello {
        margin: auto;
        width: 1200px;
        height: auto;
        text-align: center;
    }
    h1 {
        margin: 60px 0;
    }
    .el-input {
        width: 250px;
    }
</style>