<template>
<div class="index">
  <el-container>
    <!-- 头部 -->
    <el-header>
      <h3 style="float: left">博客后台管理系统</h3>
      <span style="float: right">{{name}}  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
         <el-button size="small" @click="out">退出登录</el-button></span>
    </el-header>
    <el-container>
      <!-- 侧边栏 -->
      <el-aside style="width: 200px;">
        <ul>
          <li><el-button  icon="el-icon-s-custom" type="text" @click="preson">管理人员</el-button></li>
          <li><el-button  icon="el-icon-s-unfold" type="text">分类列表</el-button></li>
          <li><el-button  icon="el-icon-tickets" type="text">文章列表</el-button></li>
        </ul>
      </el-aside>
      <!-- 内容 -->
      <el-main>
        <el-tabs :tab-position="tabPosition" style="height: 200px;">
          <el-tab-pane label="管理人员"><Admin></Admin></el-tab-pane>
          <el-tab-pane label="分类列表"><Cate></Cate></el-tab-pane>
          <el-tab-pane label="文章列表"><Article></Article></el-tab-pane>
        </el-tabs>
      </el-main>
    </el-container>
  </el-container>
  
</div>
  
</template>

<script>
import Admin from './Admin'
import Cate from './Cate'
import Article from './Article'

export default {
  data () {
    return {
      name: localStorage.getItem('name'),
      
    }
  },
  methods:{
    out () {
      localStorage.clear()
      this.$router.push('/')
    },
    preson(){

    }
  },
  components:{
    Admin,
    Cate,
    Article
  }
}
</script>

<style>
  ul li {
    list-style: none;
  }
  .index{
    margin: auto;
    height: auto;
  }
  .el-header {
    padding: 0 60px;
    width: 100Vw;
    height: 50px;
    line-height: 50px;
    background-color: #ddd
  }
  .el-aside {

    height: 500px;
    background-color: #eee;
  }
  .el-aside li {
    margin-top: 40px;
    text-align: center;

  }
</style>